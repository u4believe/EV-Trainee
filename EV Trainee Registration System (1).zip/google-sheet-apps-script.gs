// One Google Sheet = one database for Enugu + Bayelsa (download as .xlsx any time: File > Download > Microsoft Excel).
// Setup: open the Sheet > Extensions > Apps Script > paste this > Deploy > New deployment > Web app
// (Execute as: Me, Who has access: Anyone) > copy the /exec URL into the form's "Sheet endpoint" tweak.
const COLS = ['RegID','Timestamp','State','FullName','Gender','DOB','Phone','WhatsApp','Email','NIN','LGA','Address','Education','Experience','KinName','KinPhone'];

function doPost(e) {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName('Registrations') || ss.insertSheet('Registrations');
    if (sh.getLastRow() === 0) sh.appendRow(COLS);
    const d = JSON.parse(e.postData.contents);
    sh.appendRow(COLS.map(c => d[c] || ''));
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } finally { lock.releaseLock(); }
}
